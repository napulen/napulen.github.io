function a2 = geta2(beta)
    a2 = (1-beta)/(1+beta);
end