function a0 = geta0()
    a0 = 1;
end