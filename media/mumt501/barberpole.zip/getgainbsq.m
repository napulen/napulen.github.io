function gainbsq = getgainbsq(gain)
    gainbsq = (1 + gain)/2;
end