function b2 = getb2(gain, beta)
    b2 = (1 - gain*beta)/(1 + beta);
end