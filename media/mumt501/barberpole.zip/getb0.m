function b0 = getb0(gain, beta)
    b0 = (1 + gain*beta)/(1 + beta);
end