function a1 = geta1(fc, Fs, beta)
    a1 = getb1(fc, Fs, beta);
end
