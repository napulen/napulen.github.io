---
title: Display Jupyter Notebooks with Academic
subtitle: Learn how to blog in Academic using Jupyter notebooks
summary: Learn how to blog in Academic using Jupyter notebooks
authors:
- admin
tags: []
categories: []
date: "2019-02-05T00:00:00Z"
lastMod: "2019-09-05T00:00:00Z"
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
# image:
#   caption: ""
#   focal_point: "" -->

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references 
#   `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
---

# Exploring the voicing of two repeated roman numeral annotations

*If you are asked to harmonize a progression like*

```
I  IV  |  V  V  |  I  ||
```

*Should you change the voicing of the two `V` chords, or can you just repeat the same one*?


```python
import music21
from urllib.request import urlopen
import re
```

# Getting the data

The analyzed Bach chorales are located in the [KernScores](http://kern.ccarh.org/) website.

They can be visualized interactively in the [Verovio Humdrum Viewer](https://verovio.humdrum.org/).

They can also be scraped with a single query to the Kern Scores server: https://kern.humdrum.org/data?l=BachChoralesAnalyzed

I used the last approach to collect the data for this experiment.


```python
bachChoralesURL = 'https://kern.humdrum.org/data?l=BachChoralesAnalyzed'
choralesData = urlopen(bachChoralesURL).read().decode('iso-8859-1')
```


```python
# This is a hack to force music21 into reading the **harm spines
choralesData2 = re.sub(r'(\*MM[0-9]+\n)', r"\1*staff1/2/3/4\t*\t*staff1\t*staff2\t*staff3\t*staff4\n", choralesData)
# Semicolons confuse the **harm parser
choralesData2 = choralesData2.replace(';', '')
```


```python
chorales = re.split(r'!!!!SEGMENT: (chor[0-9]+)\.krn\n', choralesData2)
# The first string is empty
chorales = chorales[1:]
```


```python
out = music21.stream.Stream()
sameVoicing = []

for name, chorale in zip(chorales[0::2], chorales[1::2]):
    print(name)
    s = music21.converter.parseData(chorale, format='humdrum')
    rna = {rn.offset: rn for rn in s.flat.getElementsByClass("RomanNumeral")}
    offsets = list(rna.keys())
    pairs = zip(list(rna.values())[:-1], list(rna.values())[1:])
    filename = name
    for idx, pair in enumerate(pairs):
        rn1, rn2 = pair
        offs1 = offsets[idx]
        offs2 = offsets[idx + 1]
        if rn1.key == rn2.key and rn1.figure == rn2.figure:
            notes1 = list(
                s.flat.getElementsByOffset(
                    offs1, mustBeginInSpan=False, classList="Note"
                )
            )
            notes1 = [n.pitch.nameWithOctave for n in notes1]
            notes2 = list(
                s.flat.getElementsByOffset(
                    offs2, mustBeginInSpan=False, classList="Note"
                )
            )
            notes2 = [n.pitch.nameWithOctave for n in notes2]
            isSameVoicing = notes1 == notes2
            sameVoicing.append(isSameVoicing)
            print(
                "\t{}\t{}\t{}\t{}\t{}".format(
                    offsets[idx],
                    notes1,
                    offsets[idx + 1],
                    notes2,
                    isSameVoicing,
                )
            )
            chord1 = music21.chord.Chord(notes1, quarterLength=2)
            chord1.style.color = "green" if isSameVoicing else "red"
            chord1.addLyric(f"{offs1}")
            chord1.addLyric(filename)
            chord2 = music21.chord.Chord(notes2, quarterLength=2)
            chord2.addLyric(f"{offs2}")
            chord2.style.color = "green" if isSameVoicing else "red"
            out.append(chord1)
            out.append(chord2)
            filename = ""

same = sum(sameVoicing) / len(sameVoicing)
print(
    """
Number of consecutive identical roman numerals: {}
Same voicing: {:.2f}%
Different voicing: {:.2f}%
""".format(
        len(sameVoicing), same * 100.0, (1 - same) * 100.0
    )
)
out.insert(0, music21.clef.Treble8vbClef())
```

    chor001
    	0.0	['G4', 'D4', 'B3', 'G2']	1.0	['G4', 'D4', 'B3', 'G3']	False
    	19.0	['G4', 'D4', 'B3', 'G2']	21.0	['B4', 'G4', 'D4', 'G2']	False
    	21.0	['B4', 'G4', 'D4', 'G2']	22.0	['B4', 'G4', 'D4', 'G2']	True
    	24.0	['D5', 'G4', 'B3', 'B2']	25.0	['D5', 'G4', 'B3', 'B2']	True
    	30.0	['G4', 'E4', 'B3', 'E3']	31.0	['B4', 'E4', 'G3', 'E3']	False
    chor002
    	7.0	['E4', 'B3', 'G#3', 'E2']	8.0	['B4', 'G#4', 'E4', 'E3']	False
    chor009
    	16.0	['A4', 'F#4', 'D4', 'D3']	17.0	['A4', 'A4', 'F#4', 'D4']	False
    chor019
    	0.0	['G4', 'D4', 'B-3', 'G3']	1.0	['G4', 'D4', 'B-3', 'G3']	True
    	7.0	['F#4', 'D4', 'A3', 'D3']	8.0	['F#4', 'D4', 'A3', 'D3']	True
    	16.0	['A4', 'F4', 'C4', 'F3']	17.0	['A4', 'F4', 'C4', 'F3']	True
    	23.0	['B-4', 'D4', 'B-3', 'G3']	24.0	['B-4', 'G4', 'D4', 'G2']	False
    	27.0	['F#4', 'D4', 'A3', 'D3']	28.0	['F#4', 'D4', 'A3', 'D3']	True
    	33.0	['F#4', 'D4', 'A3', 'D3']	34.0	['F#4', 'D4', 'A3', 'D2']	False
    chor024
    	0.0	['D4', 'A3', 'F#3', 'D3']	1.0	['A4', 'D4', 'F#3', 'D3']	False
    	6.0	['D5', 'F#4', 'A3', 'D3']	7.0	['D5', 'F#4', 'A3', 'D2']	False
    	7.0	['D5', 'F#4', 'A3', 'D2']	8.0	['F#5', 'A4', 'A4', 'D4']	False
    	13.0	['D5', 'A4', 'F#4', 'D3']	16.0	['D5', 'A4', 'F#4', 'D3']	True
    	16.0	['D5', 'A4', 'F#4', 'D3']	17.0	['F#5', 'D5', 'A4', 'D4']	False
    chor028
    	6.0	['B4', 'D4', 'F#3', 'B2']	8.0	['B4', 'F#4', 'D4', 'B2']	False
    	8.0	['B4', 'F#4', 'D4', 'B2']	9.0	['D5', 'F#4', 'B3', 'B3']	False
    	22.0	['B4', 'F#4', 'D4', 'B2']	24.0	['B4', 'F#4', 'D4', 'B3']	False
    chor030
    	10.0	['E4', 'B3', 'G3', 'E2']	12.0	['G4', 'E4', 'B3', 'E3']	False
    	22.0	['E4', 'B3', 'G3', 'E3']	24.0	['G4', 'E4', 'B3', 'E3']	False
    chor032
    	0.0	['E5', 'A4', 'C#4', 'A2']	1.0	['E5', 'A4', 'C#4', 'A3']	False
    	16.0	['B4', 'G#4', 'B3', 'E3']	17.0	['B4', 'E4', 'G#3', 'E3']	False
    chor040
    	19.0	['D5', 'G4', 'B3', 'G3']	20.0	['D5', 'G4', 'B3', 'G3']	True
    chor046
    	7.0	['D5', 'F#4', 'A3', 'D3']	8.0	['D5', 'F#4', 'A3', 'D3']	True
    	9.0	['D5', 'A4', 'D4', 'F#3']	10.0	['A4', 'F#4', 'D4', 'F#3']	False
    	15.0	['F#4', 'D4', 'A3', 'D3']	16.0	['F#4', 'D4', 'A3', 'D3']	True
    chor048
    	2.0	['C5', 'E4', 'A3', 'A3']	3.0	['C5', 'E4', 'A3', 'A2']	False
    	3.0	['C5', 'E4', 'A3', 'A2']	4.0	['C5', 'E4', 'A3', 'A3']	False
    	6.0	['E5', 'G4', 'C4', 'C4']	7.0	['E5', 'G4', 'C4', 'C3']	False
    	7.0	['E5', 'G4', 'C4', 'C3']	8.0	['E5', 'G4', 'C4', 'C4']	False
    	14.0	['A4', 'E4', 'C#4', 'A2']	16.0	['E5', 'A4', 'C#4', 'A3']	False
    	22.0	['E5', 'G4', 'D4', 'D3']	23.0	['D5', 'F#4', 'A3', 'D3']	False
    	30.0	['C5', 'F4', 'C4', 'C3']	31.0	['C5', 'E4', 'G3', 'C3']	False
    	38.0	['A4', 'D4', 'A3', 'A3']	39.0	['A4', 'C#4', 'E3', 'A2']	False
    chor050
    	7.0	['A4', 'F4', 'C4', 'F3']	8.0	['A4', 'F4', 'C4', 'F3']	True
    	9.0	['C5', 'F4', 'C4', 'A3']	10.0	['C5', 'F4', 'C4', 'A2']	False
    	33.0	['C5', 'F4', 'C4', 'A3']	34.0	['C5', 'F4', 'C4', 'A3']	True
    chor054
    chor057
    	7.0	['G#4', 'E4', 'B3', 'E3']	8.0	['E5', 'G#4', 'B3', 'E3']	False
    chor067
    	14.0	['G4', 'B3', 'D3', 'G2']	16.0	['B4', 'G4', 'D4', 'G2']	False
    	24.0	['D5', 'D4', 'G3', 'B2']	25.0	['D5', 'G4', 'B3', 'G2']	False
    	32.0	['B4', 'G4', 'D4', 'G3']	33.0	['D5', 'G4', 'B3', 'G2']	False
    	40.0	['G4', 'E4', 'E3', 'E2']	42.0	['B4', 'E4', 'G3', 'E3']	False
    chor068
    chor069
    	19.0	['G4', 'D4', 'B3', 'G2']	20.0	['G4', 'D4', 'B3', 'G3']	False
    	24.0	['D5', 'F#4', 'A3', 'F#3']	25.0	['D5', 'F#4', 'A3', 'F#3']	True
    	35.0	['B4', 'G4', 'D4', 'G2']	36.0	['G4', 'D5', 'B3', 'G3']	False
    	61.0	['A4', 'E4', 'C4', 'A2']	62.0	['C5', 'E4', 'A3', 'A3']	False
    chor088
    	0.0	['A4', 'E4', 'C4', 'A2']	1.0	['A4', 'E4', 'C4', 'A3']	False
    	13.0	['A4', 'E4', 'C4', 'A2']	16.0	['E5', 'A4', 'C4', 'A2']	False
    	21.0	['B4', 'E4', 'G#3', 'E3']	24.0	['B4', 'G#4', 'E4', 'E3']	False
    chor090
    	0.0	['B-4', 'F4', 'D4', 'B-3']	1.0	['B-4', 'F4', 'D4', 'B-3']	True
    	14.0	['B-4', 'F4', 'D4', 'B-2']	15.0	['F5', 'B-4', 'D4', 'B-2']	False
    chor098
    	11.0	['C#5', 'F#4', 'B3', 'F#3']	12.0	['C#5', 'F#4', 'A#3', 'F#2']	False
    	13.0	['B4', 'D4', 'B3', 'B2']	16.0	['D5', 'B4', 'F#4', 'B3']	False
    	22.0	['D5', 'D3', 'F#4', 'A3']	23.0	['D5', 'F#4', 'A3', 'D3']	False
    	23.0	['D5', 'F#4', 'A3', 'D3']	24.0	['A4', 'F#4', 'D4', 'D3']	False
    chor101
    	13.0	['B-4', 'F4', 'D4', 'B-2']	16.0	['B-4', 'F4', 'D4', 'B-2']	True
    	16.0	['B-4', 'F4', 'D4', 'B-2']	17.0	['D5', 'B-4', 'F4', 'B-3']	False
    chor110
    	7.0	['C4', 'G3', 'E-3', 'C3']	8.0	['G4', 'E-4', 'C4', 'C4']	False
    chor117
    	3.0	['C5', 'A-4', 'E-4', 'A-3']	4.0	['A-3', 'E-5', 'C5', 'C4']	False
    	9.0	['E-5', 'A-4', 'E-4', 'C3']	10.0	['E-5', 'A-4', 'E-4', 'C3']	True
    chor124
    	0.0	['B4', 'G4', 'D4', 'G3']	1.0	['B4', 'G4', 'D4', 'G3']	True
    	7.0	['C5', 'A4', 'C4', 'A2']	8.0	['C5', 'E4', 'A3', 'A2']	False
    	9.0	['B4', 'G4', 'D4', 'G2']	10.0	['G4', 'D4', 'B3', 'G3']	False
    chor136
    	0.0	['G4', 'D4', 'B3', 'G2']	1.0	['B4', 'G4', 'D4', 'G2']	False
    chor146
    	7.0	['G#4', 'E4', 'B3', 'E3']	9.0	['E4', 'B3', 'G#3', 'E3']	False
    chor153
    	4.0	['A4', 'D4', 'E3', 'A2']	5.0	['A4', 'C#4', 'E3', 'A2']	False
    	6.0	['F#4', 'D4', 'D3', 'D2']	7.0	['F#4', 'D4', 'D3', 'D2']	True
    	7.0	['F#4', 'D4', 'D3', 'D2']	8.0	['A4', 'D4', 'F#3', 'D3']	False
    	8.0	['A4', 'D4', 'F#3', 'D3']	9.0	['A4', 'D4', 'F#3', 'D3']	True
    	16.0	['E4', 'C#4', 'A3', 'A2']	17.0	['E4', 'C#4', 'A3', 'A2']	True
    	22.0	['A4', 'C#4', 'A3', 'A2']	23.0	['A2', 'A4', 'C#4', 'A3']	False
    	30.0	['B4', 'D4', 'B3', 'B2']	31.0	['B3', 'B2', 'B4', 'D4']	False
    	32.0	['F#4', 'D4', 'A3', 'D3']	33.0	['F#4', 'D4', 'A3', 'D3']	True
    chor157
    	15.0	['F4', 'C4', 'A3', 'F2']	16.0	['C5', 'F4', 'A3', 'F3']	False
    chor158
    	15.0	['G4', 'D4', 'B3', 'G2']	16.0	['G4', 'D4', 'B3', 'G3']	False
    	57.0	['E4', 'C4', 'G3', 'C3']	58.0	['C3', 'C4', 'G3', 'E3']	False
    chor164
    chor165
    	15.0	['F4', 'C4', 'A3', 'F2']	16.0	['A4', 'F4', 'C4', 'F3']	False
    	16.0	['A4', 'F4', 'C4', 'F3']	17.0	['A4', 'F4', 'C4', 'F3']	True
    chor176
    	0.0	['F4', 'C4', 'A3', 'F2']	1.0	['F4', 'C4', 'A3', 'F3']	False
    	16.0	['C5', 'G4', 'C4', 'E3']	17.0	['C5', 'E3', 'G4', 'E4']	False
    	19.0	['A4', 'G4', 'D4', 'D3']	20.0	['A4', 'D3', 'F4', 'A3']	False
    	25.0	['C5', 'E4', 'A3', 'A3']	26.0	['C5', 'E4', 'C4', 'A3']	False
    	34.0	['F4', 'A3', 'F3', 'D3']	36.0	['F4', 'D4', 'A3', 'D3']	False
    chor177
    	0.0	['C#5', 'A4', 'E4', 'A2']	1.0	['C#5', 'A4', 'E4', 'A3']	False
    	15.0	['B4', 'E4', 'A3', 'E3']	16.0	['E4', 'B4', 'G#3', 'E3']	False
    	17.0	['A4', 'C#4', 'E3', 'A2']	20.0	['C#5', 'A4', 'E4', 'A2']	False
    	35.0	['B4', 'E4', 'A3', 'E3']	36.0	['E4', 'B4', 'G#3', 'E3']	False
    chor183
    	15.0	['G4', 'B3', 'D3', 'G2']	16.0	['G4', 'D4', 'B3', 'G3']	False
    	31.0	['G4', 'E4', 'B3', 'E3']	32.0	['B4', 'E4', 'G3', 'E3']	False
    chor187
    	13.0	['E5', 'G4', 'D4', 'C3']	14.0	['E5', 'G4', 'C4', 'C2']	False
    	15.0	['D5', 'G4', 'B3', 'G2']	16.0	['D5', 'G4', 'B3', 'G3']	False
    chor191
    	0.0	['E4', 'C4', 'A3', 'A2']	1.0	['A4', 'E4', 'C4', 'A3']	False
    	13.0	['E4', 'C4', 'A3', 'A2']	16.0	['E5', 'A4', 'C4', 'A3']	False
    	31.0	['B4', 'D4', 'G3', 'G2']	32.0	['B4', 'G4', 'D4', 'G3']	False
    chor200
    	12.0	['G4', 'D4', 'B-3', 'G2']	14.0	['G4', 'D4', 'B-3', 'G3']	False
    	28.0	['C5', 'A4', 'F4', 'F3']	29.0	['C5', 'A4', 'F4', 'F3']	True
    	48.0	['D5', 'B-4', 'F4', 'B-2']	50.0	['D5', 'B-4', 'F4', 'B-3']	False
    chor201
    	4.0	['E-4', 'D4', 'G3', 'C3']	5.0	['G4', 'E-4', 'C4', 'C3']	False
    	7.0	['B-4', 'D4', 'G3', 'G2']	8.0	['B-4', 'G4', 'D4', 'G3']	False
    	12.0	['E-4', 'C4', 'G3', 'C3']	13.0	['G4', 'E-4', 'C4', 'C3']	False
    	23.0	['E-4', 'B-3', 'G3', 'E-2']	24.0	['E-5', 'B-4', 'G3', 'E-2']	False
    	40.0	['G4', 'E-4', 'B-3', 'E-3']	41.0	['B-4', 'G4', 'E-4', 'E-3']	False
    	55.0	['F4', 'E-4', 'B-3', 'B-2']	56.0	['B-4', 'F4', 'D4', 'B-3']	False
    chor213
    	10.0	['F4', 'C4', 'A3', 'F2']	12.0	['A4', 'F4', 'C4', 'F3']	False
    chor217
    	9.0	['A4', 'F#4', 'D4', 'D3']	12.0	['A4', 'F#4', 'D4', 'D3']	True
    chor223
    	7.0	['C4', 'G3', 'E3', 'C2']	8.0	['C4', 'G3', 'E3', 'C3']	False
    	41.0	['E4', 'E4', 'G3', 'C#3']	42.0	['F#4', 'B3', 'A3', 'D#3']	False
    chor224
    	0.0	['F4', 'C4', 'A3', 'F3']	1.0	['A4', 'F4', 'C4', 'F3']	False
    	7.0	['A4', 'C4', 'F3', 'F3']	8.0	['F4', 'C4', 'A3', 'F3']	False
    	8.0	['F4', 'C4', 'A3', 'F3']	9.0	['C5', 'F4', 'A3', 'F3']	False
    chor230
    	0.0	['G4', 'D4', 'B-3', 'G2']	1.0	['G4', 'D4', 'B-3', 'G3']	False
    	7.0	['D5', 'F4', 'B-3', 'B-2']	8.0	['D5', 'F4', 'B-3', 'B-2']	True
    	23.0	['D5', 'F4', 'B-3', 'B-2']	24.0	['D5', 'F4', 'B-3', 'B-2']	True
    	24.0	['D5', 'F4', 'B-3', 'B-2']	25.0	['D5', 'F4', 'B-3', 'B-2']	True
    	25.0	['D5', 'F4', 'B-3', 'B-2']	26.0	['D5', 'F4', 'B-3', 'D3']	False
    	33.0	['B-4', 'G4', 'D4', 'G2']	34.0	['D5', 'B-4', 'B-3', 'G3']	False
    chor248
    	9.0	['B4', 'G4', 'D4', 'G3']	10.0	['G3', 'G4', 'D4', 'B3']	False
    chor255
    	1.0	['F#4', 'D4', 'A3', 'D3']	2.0	['D4', 'F#4', 'A3', 'D3']	False
    	3.0	['A4', 'D4', 'A3', 'F#3']	4.0	['A4', 'A4', 'D4', 'F#3']	False
    	5.0	['B4', 'G4', 'D4', 'G3']	8.0	['B4', 'D4', 'G3', 'G2']	False
    	9.0	['E4', 'C#4', 'G3', 'A2']	10.0	['G3', 'E4', 'C#4', 'A2']	False
    	13.0	['F#4', 'D4', 'A3', 'D3']	14.0	['D4', 'A3', 'F#3', 'D3']	False
    	31.0	['A4', 'E4', 'C#4', 'A2']	32.0	['A4', 'E4', 'C#4', 'A2']	True
    	33.0	['A4', 'F#4', 'D4', 'D3']	34.0	['A4', 'F#4', 'D4', 'D3']	True
    	41.0	['B4', 'E4', 'G#3', 'E3']	42.0	['B4', 'E4', 'G#3', 'E3']	True
    	59.0	['E4', 'D4', 'A3', 'A3']	60.0	['E4', 'C#4', 'A3', 'A2']	False
    chor258
    	33.0	['D5', 'G4', 'D4', 'B2']	34.0	['B2', 'D5', 'G4', 'B3']	False
    chor268
    	7.0	['E5', 'G4', 'C4', 'C3']	8.0	['E5', 'G4', 'C4', 'C3']	True
    	8.0	['E5', 'G4', 'C4', 'C3']	9.0	['E5', 'G4', 'E4', 'C4']	False
    	15.0	['C5', 'E4', 'G3', 'C3']	16.0	['C5', 'E4', 'G3', 'C3']	True
    	23.0	['A4', 'E4', 'C4', 'A2']	24.0	['A4', 'E4', 'C4', 'A3']	False
    	29.0	['G4', 'D4', 'B3', 'G2']	30.0	['G4', 'D4', 'B3', 'G3']	False
    	39.0	['F5', 'F4', 'D4', 'D3']	40.0	['F5', 'A4', 'F4', 'D4']	False
    	57.0	['G4', 'D4', 'B3', 'G2']	58.0	['G4', 'D4', 'B3', 'G2']	True
    chor272
    chor273
    	15.0	['D4', 'A3', 'F#3', 'D3']	16.0	['D4', 'D4', 'F#3', 'D3']	False
    chor276
    	3.0	['D5', 'G4', 'B3', 'G3']	4.0	['D5', 'G4', 'G3', 'B3']	False
    	13.0	['D5', 'D4', 'F#4', 'D3']	16.0	['D5', 'F#4', 'D4', 'D3']	False
    chor281
    	0.0	['G4', 'D4', 'B-3', 'G2']	1.0	['G4', 'D4', 'B-3', 'G3']	False
    	31.0	['B-4', 'F4', 'D4', 'B-2']	32.0	['D5', 'B-4', 'F4', 'B-3']	False
    chor282
    	14.0	['C5', 'G4', 'E4', 'C3']	16.0	['E5', 'G4', 'C4', 'C4']	False
    	32.0	['E5', 'G4', 'C4', 'C4']	33.0	['G5', 'C5', 'E4', 'C3']	False
    chor290
    	0.0	['B4', 'G#4', 'E4', 'E3']	1.0	['B4', 'F#4', 'B3', 'E3']	False
    	9.0	['G#4', 'E4', 'B3', 'E3']	10.0	['E3', 'E4', 'B3', 'G#3']	False
    	31.0	['G#4', 'F#4', 'C#4', 'C#3']	32.0	['G#4', 'E#4', 'C#4', 'C#4']	False
    chor299
    	4.0	['D5', 'A-4', 'F4', 'B-3']	5.0	['D5', 'A-4', 'F4', 'B-2']	False
    	10.0	['E-5', 'G4', 'D4', 'C3']	11.0	['G4', 'E-5', 'C4', 'E-3']	False
    	14.0	['C5', 'F4', 'B-3', 'F3']	15.0	['C5', 'F4', 'A3', 'F2']	False
    	34.0	['E-4', 'B-3', 'G3', 'E-3']	36.0	['B-4', 'G4', 'E-4', 'E-4']	False
    	41.0	['D5', 'G4', 'D4', 'B2']	41.5	['G4', 'E-5', 'B3', 'G2']	False
    chor303
    	13.0	['F4', 'C4', 'A3', 'F2']	16.0	['F4', 'C4', 'A3', 'F3']	False
    chor305
    	30.0	['F#4', 'D4', 'A3', 'D3']	32.0	['F#4', 'D4', 'A3', 'D3']	True
    	34.0	['E4', 'C#4', 'A3', 'A3']	35.0	['E4', 'C#4', 'A3', 'A3']	True
    chor306
    	4.0	['D4', 'E-4', 'G3', 'C3']	5.0	['G4', 'E-4', 'C4', 'C3']	False
    	7.0	['B-4', 'D4', 'G3', 'G2']	8.0	['B-4', 'G4', 'D4', 'G3']	False
    	12.0	['E-4', 'C4', 'G3', 'C3']	13.0	['G4', 'E-4', 'C4', 'C3']	False
    	23.0	['E-4', 'B-3', 'G3', 'E-2']	24.0	['E-5', 'B-4', 'G3', 'E-2']	False
    	40.0	['G4', 'E-4', 'B-3', 'E-3']	41.0	['B-4', 'G4', 'E-4', 'E-3']	False
    	55.0	['F4', 'E-4', 'B-3', 'B-2']	56.0	['B-4', 'F4', 'D4', 'B-3']	False
    chor311
    	7.0	['A4', 'F4', 'C4', 'F3']	8.0	['A4', 'F4', 'C4', 'F3']	True
    chor315
    	5.0	['B4', 'G4', 'D4', 'G2']	8.0	['B4', 'G4', 'D4', 'G2']	True
    chor323
    	31.0	['A4', 'F4', 'C4', 'F2']	33.0	['A4', 'F4', 'C4', 'F2']	True
    chor328
    	0.0	['B4', 'D4', 'G3', 'G2']	1.0	['A4', 'D4', 'B3', 'G3']	False
    	16.0	['G4', 'D4', 'B3', 'G2']	20.0	['D4', 'B3', 'G3', 'G2']	False
    	26.0	['F#4', 'D4', 'A3', 'D3']	27.0	['D4', 'A3', 'F#3', 'D3']	False
    	30.0	['G4', 'E4', 'E3', 'C3']	31.0	['G4', 'E4', 'G3', 'C3']	False
    chor336
    chor339
    	23.0	['E5', 'C5', 'C4', 'E3']	24.0	['E5', 'C5', 'E4', 'C3']	False
    	27.0	['C5', 'G4', 'E4', 'C3']	28.0	['E5', 'G4', 'C4', 'C3']	False
    chor345
    	7.0	['E4', 'B3', 'G#3', 'E3']	8.0	['B4', 'E4', 'G#3', 'E3']	False
    	13.0	['A4', 'E4', 'C4', 'A2']	16.0	['C5', 'A4', 'E4', 'A3']	False
    	22.0	['C5', 'E4', 'G3', 'C3']	23.0	['C5', 'E4', 'G3', 'C3']	True
    	23.0	['C5', 'E4', 'G3', 'C3']	24.0	['G4', 'E4', 'C4', 'C3']	False
    	33.0	['B4', 'D4', 'G3', 'G3']	34.0	['D5', 'G4', 'B3', 'G3']	False
    chor350
    	6.0	['C5', 'A4', 'F4', 'F3']	7.0	['C5', 'A4', 'F4', 'F3']	True
    	22.0	['C5', 'E-4', 'G3', 'C3']	24.0	['E-5', 'G4', 'C4', 'C4']	False
    	38.0	['C5', 'F4', 'A3', 'F3']	39.0	['C5', 'F4', 'A3', 'F3']	True
    	46.0	['B-4', 'F4', 'D4', 'B-2']	47.0	['B-4', 'F4', 'D4', 'B-2']	True
    chor354
    	9.0	['B4', 'G4', 'D4', 'G3']	10.0	['G3', 'G4', 'D4', 'B3']	False
    chor361
    	16.0	['A4', 'F#4', 'D4', 'D3']	17.0	['A4', 'A4', 'F#4', 'D4']	False
    chor366
    	7.0	['C#5', 'E4', 'A3', 'A2']	8.0	['C#5', 'A4', 'E4', 'A3']	False
    	9.0	['E5', 'A4', 'E4', 'C#4']	10.0	['E5', 'A4', 'E4', 'C#3']	False
    	15.0	['G#4', 'E4', 'B3', 'E3']	16.0	['E4', 'B3', 'G#3', 'E3']	False
    	27.0	['C#5', 'E4', 'A3', 'A3']	28.0	['E5', 'C#4', 'A3', 'A3']	False
    	43.0	['C#5', 'A3', 'E3', 'C#3']	44.0	['E3', 'E5', 'A4', 'C#3']	False
    chor368
    	24.0	['G4', 'E4', 'C4', 'C3']	27.0	['E5', 'G4', 'C4', 'C3']	False
    	45.0	['G5', 'G4', 'C4', 'E3']	46.0	['C4', 'C5', 'G4', 'E3']	False
    	49.0	['F3', 'D5', 'B-3', 'B-2']	50.0	['B-2', 'B-4', 'F4', 'D4']	False
    	51.0	['G4', 'F4', 'G3', 'C3']	52.0	['G4', 'E4', 'C4', 'C3']	False
    
    Number of consecutive identical roman numerals: 190
    Same voicing: 22.11%
    Different voicing: 77.89%
    



![png](output_9_1.png)


In the table above, offsets are given in quarter notes from the beginning of the score (starting from 0.0). 

In all instances, `chord1` and `chord2` are contiguous, express the same chord (i.e., same roman numeral in the same key context), and have been annotated by a human expert.


```python
# Show some of the scores
out.show()
```


![png](output_11_0.png)


In the figure above, red-colored pairs represent a change in the voicing between the two contiguous annotations of the same roman numeral.

Green-colored pairs show examples in which the voicing was identical in the two contiguous annotations.

Generally, when a voice-leading algorithm finds two contiguous instances of the same roman numeral, it should be safe to assume that the voicing should change. For example, with a change of position in the three upper voices and/or changing the octave of the bass. 


```python

```
